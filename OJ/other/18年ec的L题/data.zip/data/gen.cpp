#include <iostream>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <cassert>
#include <ctime>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define mp make_pair
int n=100000,m=100000;
vector<int> A[2];
const int N=110000;
map<int,int> M[N];
int main(){
	srand(time(0));
	//n=rand()%100000+1;
	//m=rand()%100000+1;
	m=0;
	printf("%d %d\n",n,m);
	int key=0; if (rand()&1) key=100;
	for (int i=1;i<=n;i++){
		int now=0;
		if (rand()%100<key) now=1; else now=0;
		A[now].push_back(i);
		printf("%d",now);
		if (i==n) puts(""); else putchar(' ');
	}
	int Mm=0;
	for (int i=1;i<=Mm;i++)
		while (1){
			int k1=A[0][rand()%A[0].size()],k2=A[1][rand()%A[1].size()];
			if (M[k1][k2]||k1==k2) continue;
			M[k1][k2]=1; M[k2][k1]=1;
			if (rand()&1) swap(k1,k2);
			printf("%d %d\n",k1,k2);
			break;
		}
	for (int i=Mm+1;i<=m;i++)
		while (1){
			int k1=rand()%n+1,k2=rand()%n+1;
			if (M[k1][k2]||k1==k2) continue;
			M[k1][k2]=1; M[k2][k1]=1;
			if (rand()&1) swap(k1,k2);
			printf("%d %d\n",k1,k2);
			break;
		}
}
